<?php
require('../../class/connect.php'); //引入数据库配置文件和公共函数文件
require('../../class/db_sql.php'); //引入数据库操作文件
require('../../class/userfun.php'); //引入数据库操作文件
$link=db_connect(); //连接MYSQL
$empire=new mysqlquery(); //声明数据库操作类
$editor=1; //声明目录层次
$limit=$_POST[limit];
$num =(int)$_POST['next'] *$limit;
$where=" where 1=1  ";
$keyword=$_POST[keyword];
$where.=$keyword ? " and title LIKE '%".$keyword."%' ":'';
$orderby=$_POST[orderby]?"order by ".$_POST[orderby]:'';
if($orderby){
$px=$_POST[myorder]?" desc":" asc";
}
$where.=$orderby.$px;
$sql="SELECT title,titlepic,titleurl,price FROM {$dbtbpre}ecms_shop ".$where." LIMIT $num,$limit ";
$res=mysql_query($sql);
while($bqr=mysql_fetch_assoc($res))
{
?>
  <li>
    <a href="<?=$bqr[titleurl]?>" onclick="">
      <div class="s_goodsinfo">
        <img src="<?=$bqr[titlepic]?>" role="<?=$bqr[title]?>" title=" <?=$bqr[title]?>" class="pro-img">
        <h4><?=$bqr[title]?></h4>
        <b>￥<?=$bqr[price]?></b>
      </div>
    </a>
  </li>
<?php 
} 
db_close(); //关闭MYSQL链接
$empire=null; //注消操作类变量
?>